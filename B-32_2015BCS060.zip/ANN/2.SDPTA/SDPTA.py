import numpy as np
x_input = np.array([[0,0,1],[0,1,1],[1,0,1],[1,1,1]])
x_OR_label = np.array([-1,1,1,1])
x_AND_label = np.array([-1,-1,-1,1])
choice = int(input("Enter operation for which you want to train the neuron:\n1.AND\t2.OR\n"))
if(choice == 1):
    x_label = x_AND_label
else:
    x_label = x_OR_label
w = np.array([-1,-2,-3])
count = 0
while True:
    error = 0
    training_cycle()
    if(error==0):
        break
print("No. of steps required: %s"%count)
print("Weight vector after adjustment is: {}".format(w))

def training_cycle():
    global x,w,count,error
    index = 0
    for input_vector in x_input:
        count = count+1
        net = np.matmul(w.T,input_vector)
        if(net>0):
            output = 1
        elif(net<0):
            output = -1
        else:
            output = -1*x_label[index]
        if(x_label[index] != output):
            error = error+2
            w = w +(0.5*(x_label[index]-output))*input_vector
        index = index+1

