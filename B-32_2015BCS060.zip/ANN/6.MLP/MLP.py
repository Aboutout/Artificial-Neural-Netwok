
# coding: utf-8

# In[3]:


import numpy as np
import math


# In[70]:


z = np.array([[0,0,-1],[1,0,-1],[0,1,-1],[1,1,-1]])
d = np.array([[0],[1],[1],[0]])
X = len(z)
I = len(z[0])
J = int(input("Enter the no. of neurons in hidden layer: "))+1
K = len(d[0])
W = np.random.rand(K,J)
V = np.random.rand(J-1,I)
n = 0.1
cycle_count = 0
emax = 0.0001


# In[71]:


while True:
    error = 0
    cycle_count = cycle_count+1
    for x in range(X):
        y = list()
        for j in range(J-1):
            net = np.matmul(V[j],z[x])
            output = (1-math.exp(-net))/(1+math.exp(-net))
            y.append(output)
        y.append(-1)
        y = np.array(y).reshape(J,1)
        deltaO = list()
        for k in range(K):
            net = np.matmul(W[k],y)
            output = (1-math.exp(-net))/(1+math.exp(-net))
            error = error + 0.5*(d[x][k]-output)**2
            deltaO.append((d[x][k]-output)*(1-output**2))
        deltaO = np.array(deltaO).reshape(K,1)
        deltay = list()
        for j in range(J-1):
            deltay.append(np.matmul(W[:,j],deltaO)[0]*0.5*(1-y[j]**2))
        deltay = np.array(deltay).reshape(J-1,1)
        W = W + n*np.matmul(deltaO,y.T)
        V = V + n*np.matmul(deltay,z[x].reshape(1,I))
    if(error<emax):
        break


# In[74]:


print("Weight vector W after adjustment is:\n {}".format(W))
print("Weight vector V after adjustment is:\n {}".format(V))
print("Final error in the neural network is: %f"%error)
print("No. of training cycles required to train the network are: %d"%cycle_count)

