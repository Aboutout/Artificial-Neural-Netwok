import numpy as np
import math
print("Enter input vector:")
x = np.array([int(i) for i in raw_input().split()])
print("Enter weight vector:")
w = np.array([int(i) for i in raw_input().split()])
net = np.matmul(w.T,x)


def choose():
    print("\n1.Unipolar Theshold\n2.Bipolar Threshold\n3.Unipolar Sigmoid\n4.Bipolar Sigmoid")
    choice = int(raw_input("Choose the activation function: "))
    return choice

def unipolar_threshold():
    if(net <= 0):
        print("0")
    else: 
        print("1")

def bipolar_threshold():
    if(net <= 0):
        print("Output of the neuron is: -1")
    else: 
        print("Output of the neuron is: 1")

def unipolar_sigmoid():
    lamda = int(raw_input("Enter the stiffness factor: "))
    output = 1/(1+math.exp(float(-lamda*net)))
    print("Output of the neuron is: {}".format(output))

def bipolar_thershold():
    lamda = int(raw_input("Enter the stiffness factor: "))
    output = (1-math.exp(float(-lamda*net)))/(1+math.exp(float(-lamda*net)))
    print("Output of the neuron is: {}".format(output))

cont=1
while(cont==1):
    choice = choose()
    if(choice == 1):
        unipolar_threshold()
    elif(choice == 2):
        bipolar_threshold()
    elif(choice == 3):
        unipolar_sigmoid()
    elif(choice == 4):
        bipolar_sigmoid()
    print("\nDo you want to continue?")
    cont = input("1.Yes\n2.No")

if __name__ == '__main__':
	
