
# coding: utf-8

# In[7]:


import numpy as np
import math
x_input = np.array([[0,0,1],[0,1,1],[1,0,1],[1,1,1]])
x_OR_label = np.array([-1,1,1,1])
x_AND_label = np.array([-1,-1,-1,1])
choice = int(input("Enter operation for which you want to train the neuron:\n1.AND\t2.OR\n"))
if(choice == 1):
    x_label = x_AND_label
else:
    x_label = x_OR_label
w = np.array([-1,-2,-3])
count = 0
emax = 0.001
while True:
    error = 0
    training_cycle()
    if(error<emax):
        break
print("No. of steps required: %s"%count)
print("Weight vector after adjustment is: {}".format(w))
print("Final error: {}".format(error))


# In[5]:


def training_cycle():
    global x,w,count,error
    index = 0
    for input_vector in x_input:
        count = count+1
        net = np.matmul(w.T,input_vector)
        output = (1-math.exp(-net))/(1+math.exp(-net))
        error = error + 0.5*(x_label[index]-output)**2
        w = w + 0.5*(x_label[index]-output)*(1-output**2)*input_vector
        index = index+1

