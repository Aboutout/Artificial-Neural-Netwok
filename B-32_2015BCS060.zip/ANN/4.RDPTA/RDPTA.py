import numpy as np
x_input = np.array([[10,2,-1],[2,-5,-1],[-5,5,-1]])
x_label = np.array([[1,-1,-1],[-1,1,-1],[-1,-1,1]])
w = np.asarray([[1,-2,0],[0,-1,2],[1,3,-1]])
count = 0
cycle_count = 0
while True:
    error = [0,0,0]
    training_cycle()
    if(error==[0,0,0]):
        break
print("No. of training cycles required: %s"%cycle_count)
print("No. of steps required: {:.0f}".format(count/3))
print("Weight matrix after adjustment is:\n {}".format(w))

def training_cycle():
    global x_input,x_label,w,count,error,cycle_count
    cycle_count = cycle_count+1
    for i in range(3):
        index = 0
        for input_vector in x_input:
            net = np.matmul(w[i].T,input_vector)
            if(net>0):
                output = 1
            elif(net<0):
                output = -1
            else:
                output = -1*x_label[index][i]
            if(x_label[index][i] != output):
                error[i] = error[i]+2
                w[i] = w[i] +(0.5*(x_label[index][i]-output))*input_vector
            index = index+1
            count = count+1